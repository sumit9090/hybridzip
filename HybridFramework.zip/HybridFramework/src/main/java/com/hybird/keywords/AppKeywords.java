package com.hybird.keywords;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;

public class AppKeywords extends GenericKeywords{

	
	public void login(){
		test.log(Status.INFO, "Logging in"); 
		
		String username="";
		String password="";
		
		if(data.get("Username") == null){
			username=envProp.getProperty("adminusername");
			password=envProp.getProperty("adminassword");
		}else{
			username=data.get("Username");
			password=data.get("Password");
		}
		getObject("username_id").sendKeys(username);
		getObject("emailsubmit_id").click();
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.visibilityOf(getObject("password_id")));
		
		getObject("password_id").sendKeys(password);
		getObject("continue_id").click();
		// security warining - mozilla
		wait(5);
		
		
		wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("password_id")));
	}
	
	
	public void validateLogin(){
		test.log(Status.INFO, "Validating Login");
		String expectedResult = data.get(dataKey);
		String actualResult="";
		
		boolean result = isElementPresent("crmLink_xpath");
		if(result)
			actualResult = "LoginSuccess";
		else
			actualResult= "LoginFailure";
		
		
		if(!expectedResult.equals(actualResult))
			reportFailure("Got result as "+ actualResult);
	}
	
	public void defaultLogin(){
		String username=envProp.getProperty("adminusername");
		String password=envProp.getProperty("adminpassword");
		System.out.println("Default username "+username );
		System.out.println("Default password "+password );
	}
	
}